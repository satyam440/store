<?php
function stm_lms_plans_model()
{
    $schema = array(
        '$schema' => 'http://json-schema.org/draft-04/schema#',
        'title' => 'plans',
    );

    return $schema;

}