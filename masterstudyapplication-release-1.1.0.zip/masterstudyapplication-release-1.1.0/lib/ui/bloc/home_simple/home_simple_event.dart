import 'package:meta/meta.dart';

@immutable
abstract class HomeSimpleEvent {}

class FetchHomeSimpleEvent extends HomeSimpleEvent {}