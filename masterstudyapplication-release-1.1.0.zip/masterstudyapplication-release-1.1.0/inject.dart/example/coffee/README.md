This is an adaptation of the "Coffee"
[example from Dagger 2](https://github.com/google/dagger/tree/master/examples/simple/src/main/java/coffee).

Some features are missing or incomplete.

To run the example:
```bash
$ pub run build_runner test
```
